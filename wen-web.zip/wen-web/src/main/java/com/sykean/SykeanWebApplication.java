package com.sykean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SykeanWebApplication {
    public static void main(String[] args) {
        SpringApplication.run(SykeanWebApplication.class, args);
    }

}