package com.sykean.common;

import org.springframework.stereotype.Controller;

@Controller
public class BaseController {
}